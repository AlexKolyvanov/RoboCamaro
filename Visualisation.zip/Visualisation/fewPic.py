from Tkinter import *
from math import *
radius=100;



root = Tk()

root.title('Example app')
bcanv = Canvas(root,width=500,height=500,bg="lightblue", cursor="pencil")
bcanv.pack()
arrow = bcanv.create_line(250,250,205,342,width=3,arrow=LAST) 

crug = bcanv.create_arc([140,140],[360,360],start=-20,extent=270,width=3,style=ARC)
#crug2 = bcanv.create_oval([150,150],[350,350], width=1)
#crugl = bcanv.create_arc([140,140],[360,360],start=10,extent=270, fill='#990000',width=1,style=ARC,)


scal=Scale(orient=HORIZONTAL, length=200, from_ =328, to = 71)
scal.pack()



#

coords = Label(root, text ='coords')
coords.pack()

#rcanv = Canvas(root, width=500, height=100, bg="pink")
#rcanv.pack()
#speedArrow = rcanv.create_line(0,0,100,100, width =5, arrow=LAST)

def getXY(event):
    #print 'started'             
    print (scal.get())
    

    scalCur =scal.get()

    xk=250+100*sin(radians(scalCur))
    yk=250+100*cos(radians(scalCur))
    bcanv.coords(arrow,250,250,xk,yk) 

    
    getx=str(event.x_root)        
    gety=str(event.y_root)                      
    coords.config(text = 'x='+getx+', '+'y='+gety)
root.bind('<Motion>', getXY)





root.mainloop()
