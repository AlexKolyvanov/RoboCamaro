from Tkinter import *
from PIL import Image, ImageTk
from math import *
import sched, time
from threading import Thread
import threading

from __builtin__ import int
from serial import *
from serial import Serial
lights = [1,2,3,4,5]
leds=[0,1,2,3,4,5,6,7,8,9,10]
array=[]

SERIAL_PORT = 'COM9'
SERIAL_SPEED = 38400

blueCanvHeight =600
blueCanvWidth=800

root = Tk()
ser = Serial(SERIAL_PORT, SERIAL_SPEED, dsrdtr = 1,timeout =1)
o = ser.readline().strip()    
camaro = Image.open("Comaro.jpg")
svetofor =Image.open("Svetoforvkart.png")
speedometr=ImageTk.PhotoImage(Image.open("spedometr2.png"))
peshehod = ImageTk.PhotoImage(Image.open("peshehod.png"))
stopsignals = ImageTk.PhotoImage(Image.open("StopSignals.png"))
reverssignals = ImageTk.PhotoImage(Image.open("ReversSignals.png"))
znakStop = ImageTk.PhotoImage(Image.open("ZnakStopV1.png"))

lights[0] = ImageTk.PhotoImage(Image.open("RedLight.png"))
lights[1] = ImageTk.PhotoImage(Image.open("RedYellowLight.png")) 
lights[2] = ImageTk.PhotoImage(Image.open("YellowLight.png"))                               
lights[3] = ImageTk.PhotoImage(Image.open("GreenLight.png"))                                          
lights[4] = ImageTk.PhotoImage(Image.open("HalfGreenLight.png"))   

canv= Canvas(root, height =blueCanvHeight, width=blueCanvWidth,bg='blue')
photo = ImageTk.PhotoImage(camaro)
photosvet = ImageTk.PhotoImage(svetofor)
item4=canv.create_image(blueCanvWidth/2,300,image=photo)
item45=canv.create_image(blueCanvWidth-150,blueCanvHeight-150,image=speedometr)
item5=canv.create_image(blueCanvWidth/2,100,image=photosvet)
#item55=canv.create_image(blueCanvWidth-100,100,image=znakStop,tags=('light','znakStop'))
item56=canv.create_image(100,100,image=peshehod,tags=('light','peshehod'))
item6=canv.create_image(blueCanvWidth/2,55,image=lights[0],tags=('light','red'))
item7=canv.create_image(blueCanvWidth/2,80,image=lights[1],tags=('light','redYellow'))
item8=canv.create_image(blueCanvWidth/2,106,image=lights[2],tags=('light','yellow'))
item85=canv.create_image(blueCanvWidth/2,156,image=lights[3],tags=('light','green'))
item86=canv.create_image(blueCanvWidth/2,156,image=lights[4],tags=('light','halfGreen'))

item9=canv.create_image(188,382,image=stopsignals,tags=('signals','stop'))
item10=canv.create_text(blueCanvWidth-150,550, font=('courier', 20),fill='red' )
#speedCrug = canv.create_arc([800,300],[1000,500],start=-20,extent=270,width=3,style=ARC)
speedArrow = canv.create_line(blueCanvWidth-150,blueCanvHeight-150,700,400,width=5,arrow=LAST, fill='red') 


#scal=Scale(orient=HORIZONTAL, length=200, from_ =0, to = 7)
#scal.grid(row=0,column=1)
#scalSpeed=Scale(orient=HORIZONTAL, length=200, from_ =300, to = 60)
#scalSpeed.grid(row=0, column=2)
canv.grid(row=1,column=1,columnspan=2)

class MyThread(Thread):
    def __init__(self, event, function):
        Thread.__init__(self)
        self.stopped = event
        self.function = function

    def run(self):
        while True:
            self.function()
            time.sleep(1 / 60)

def serialReading():
    global s, array
    ser.flushInput()
    s=0
    o = ser.readline().strip()
    st= ser.readline().strip()
    array=st.split()
    
    svetofor()
    

def svetofor():
    global array
    #canv.itemconfig('light',state=HIDDEN)
    #print int(array[4])

   
    if (int(array[4]) == 0) : canv.itemconfig('red', state=NORMAL)
    else :canv.itemconfig('red', state=HIDDEN)

    if (int(array[4]) == 1) :canv.itemconfig('redYellow', state=NORMAL)
    else :canv.itemconfig('redYellow', state=HIDDEN)

    if (int(array[4]) == 2):canv.itemconfig('green', state=NORMAL)
    else : canv.itemconfig('green', state=HIDDEN)

    if (int(array[4]) == 3) : canv.itemconfig('halfGreen', state=NORMAL)
    else : canv.itemconfig('halfGreen', state=HIDDEN)

    #if (int(array[4]) == 3) : canv.itemconfig('yellow', state=NORMAL)
    #else : canv.itemconfig('yellow', state=HIDDEN)

    if (int(array[4]) == 4) : canv.itemconfig('yellow', state=NORMAL)
    else : canv.itemconfig('yellow', state=HIDDEN)
        
    if (int(array[3]) == 1) : canv.itemconfig('peshehod', state=NORMAL)
    else : canv.itemconfig('peshehod', state=HIDDEN)

    #if (int(array[7]) == 1) : canv.itemconfig('znakStop', state=NORMAL)
    #else : canv.itemconfig('znakStop', state=HIDDEN)
    
        
    if (int(array[2]) == 300): canv.itemconfig('stop', state=NORMAL)
    else : canv.itemconfig('stop', state=HIDDEN)
    speedak()

def speedak():
    global array
    curSpeed=int(array[2])
    #print (curSpeed)
    xk=(blueCanvWidth-150)+100*sin(radians(curSpeed))
    yk=(blueCanvHeight-150)+100*cos(radians(curSpeed))
    canv.coords(speedArrow,blueCanvWidth-150,blueCanvHeight-150,xk,yk)

    factCurSpeed=int(array[5])
    canv.itemconfig(item10, text=factCurSpeed)
    steering()
    
def steering():
    global array
    steeringAngle=int(array[1])
    xklf=100+50*sin(radians(-steeringAngle))
    yklf=450+50*cos(radians(-steeringAngle))
    xklt=100-50*sin(radians(-steeringAngle))
    yklt=450-50*cos(radians(-steeringAngle))
    zcanv.coords(frontWheelLeft,xklt,yklt,xklf,yklf)

    xkrf=400+50*sin(radians(-steeringAngle))
    ykrf=450+50*cos(radians(-steeringAngle))
    xkrt=400-50*sin(radians(-steeringAngle))
    ykrt=450-50*cos(radians(-steeringAngle))
    zcanv.coords(frontWheelRight,xkrt,ykrt,xkrf,ykrf)

    xkbl=int(array[0])+250
    zcanv.coords(blackLine, xkbl,0,xkbl,400)
    logging()

def logging():
    logtext = 'Line position = '+str(array[0])+'; Turn angle = '+str(array[1])+'; Speed = '+str(array[5])+'; Peshehod = '+str(array[3])+'; SvetSignal = '+str(array[4])+'; leds = '+str(array[6])
    logLine.config(text=logtext)
    ledding()
    
def ledding():
   
   i=0
   for led in leds:
       if (int(array[6][-i-1])==1) : zcanv.itemconfig(leds[i], fill='green', outline='green')
       else : zcanv.itemconfig(leds[i], fill='black', outline='black')
       print(i)
       i=i+1

        
def exited():
    ser.close()
    root.destroy()
    #stopFlag.set()
    

stopFlag = Event()
thread = MyThread(stopFlag, serialReading)
thread.start()
# stopFlag.set()

#root.bind('<Motion>', svetofor)

#scalAngle=Scale(orient=HORIZONTAL, length=200, from_ =-30, to = 30)
#scalAngle.grid(row=0,column=0)


zcanv = Canvas(root, height =600, width=500,bg='green')
frontWheelLeft = zcanv.create_line(100,400,100,500,width=40)
frontWheelRight = zcanv.create_line(400,400,400,500,width=40)

blackLine=zcanv.create_line(250,0,250,400,width=5)

frame1=zcanv.create_line(100,450,400,450,width=5)
frame2=zcanv.create_rectangle(150,380,350,600,width=5)
frame3=zcanv.create_rectangle(85,520,415,600,width=5)
SensLine=ImageTk.PhotoImage(Image.open("SensLine2.png"))
frame4=zcanv.create_image(250,350,image=SensLine)

leds[0]=zcanv.create_oval(80,365,85,370,fill='black', width=3)
leds[1]=zcanv.create_oval(115,355,120,360,fill='black', width=3)
leds[2]=zcanv.create_oval(150,345,155,350,fill='black', width=3)
leds[3]=zcanv.create_oval(185,335,190,340,fill='black', width=3)
leds[4]=zcanv.create_oval(216,325,221,330,fill='black', width=3)
leds[5]=zcanv.create_oval(248,315,253,320,fill='black', width=3)
leds[6]=zcanv.create_oval(283,325,288,330,fill='black', width=3)
leds[7]=zcanv.create_oval(320,335,325,340,fill='black', width=3)
leds[8]=zcanv.create_oval(355,345,360,350,fill='black', width=3)
leds[9]=zcanv.create_oval(388,355,393,360,fill='black', width=3)
leds[10]=zcanv.create_oval(418,365,423,370,fill='black',width=3)
zcanv.grid(row=1, column=0)


logLine=Label(root, text='logtext')
logLine.grid(row= 3, column =1)

exbut = Button(root, command = exited, width= 80,
               height =1, text = 'x', bg ='red',
               foreground ='blue',font=('courier', 20))
exbut.grid(row= 4, column =0,columnspan=2)


var = 0
def fullscreen(event):
    global var
    if var == 0:
        root.attributes("-fullscreen", True)
        var = 1
    else:
        root.attributes("-fullscreen", False)
        var = 0

root.bind("<F11>", fullscreen)





root.mainloop()
ser.close()
