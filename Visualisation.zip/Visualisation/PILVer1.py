from Tkinter import *
from PIL import Image, ImageTk
from math import *
lights = [1,2,3]

blueCanvHeight =600
blueCanvWidth=800

root = Tk()
#root.attributes('-fullscreen', True)


camaro = Image.open("E:/Robototechnics/Camaro/Visualisation/Comaro.jpg")
svetofor =Image.open("E:/Robototechnics/Camaro/Visualisation/Svetoforvkart.png")
speedometr=ImageTk.PhotoImage(Image.open("E:/Robototechnics/Camaro/Visualisation/spedometr2.png"))
peshehod = ImageTk.PhotoImage(Image.open("E:/Robototechnics/Camaro/Visualisation/peshehod.png"))
stopsignals = ImageTk.PhotoImage(Image.open("E:/Robototechnics/Camaro/Visualisation/StopSignals.png"))
reverssignals = ImageTk.PhotoImage(Image.open("E:/Robototechnics/Camaro/Visualisation/ReversSignals.png"))

lights[0] = ImageTk.PhotoImage(Image.open("E:/Robototechnics/Camaro/Visualisation/RedLight.png"))
lights[1] = ImageTk.PhotoImage(Image.open("E:/Robototechnics/Camaro/Visualisation/YellowLight.png"))                               
lights[2] = ImageTk.PhotoImage(Image.open("E:/Robototechnics/Camaro/Visualisation/GreenLight.png"))                                          

canv= Canvas(root, height =blueCanvHeight, width=blueCanvWidth,bg='blue')
photo = ImageTk.PhotoImage(camaro)
photosvet = ImageTk.PhotoImage(svetofor)
item4=canv.create_image(blueCanvWidth/2,300,image=photo)
item45=canv.create_image(blueCanvWidth-150,500,image=speedometr)
item5=canv.create_image(blueCanvWidth/2,100,image=photosvet)
item55=canv.create_image(100,100,image=peshehod,tags=('light','peshehod'))
item6=canv.create_image(blueCanvWidth/2,55,image=lights[0],tags=('light','red','redYellow'))
item7=canv.create_image(blueCanvWidth/2,106,image=lights[1],tags=('light','yellow','redYellow'))
item8=canv.create_image(blueCanvWidth/2,156,image=lights[2],tags=('light','green'))
item9=canv.create_image(188,382,image=stopsignals,tags=('signals','stop'))
item10=canv.create_image(175,420,image=reverssignals,tags=('signals','revers'))

#speedCrug = canv.create_arc([800,300],[1000,500],start=-20,extent=270,width=3,style=ARC)
speedArrow = canv.create_line(blueCanvWidth-150,500,700,400,width=5,arrow=LAST, fill='red') 


scal=Scale(orient=HORIZONTAL, length=200, from_ =0, to = 7)
scal.grid(row=0,column=1)
scalSpeed=Scale(orient=HORIZONTAL, length=200, from_ =300, to = 60)
scalSpeed.grid(row=0, column=2)
canv.grid(row=1,column=1,columnspan=2)
def svetofor(event):
    canv.itemconfig('light',state=HIDDEN)
    if (scal.get() == 1) : canv.itemconfig('red', state=NORMAL)
    if (scal.get() == 2) : canv.itemconfig('redYellow', state=NORMAL)
    if (scal.get() == 3) : canv.itemconfig('green', state=NORMAL)
    if (scal.get() == 4) : canv.itemconfig('yellow', state=NORMAL)
    if (scal.get() == 5) : canv.itemconfig('red', state=NORMAL)
    if (scal.get() == 7) : canv.itemconfig('light', state=NORMAL)
    speedak()

def speedak():
    curSpeed=scalSpeed.get()
    xk=(blueCanvWidth-150)+100*sin(radians(curSpeed))
    yk=500+100*cos(radians(curSpeed))
    canv.coords(speedArrow,blueCanvWidth-150,500,xk,yk)
    steering()
    
def steering():
    steeringAngle=scalAngle.get()
    xklf=100+50*sin(radians(-steeringAngle))
    yklf=450+50*cos(radians(-steeringAngle))
    xklt=100-50*sin(radians(-steeringAngle))
    yklt=450-50*cos(radians(-steeringAngle))
    zcanv.coords(frontWheelLeft,xklt,yklt,xklf,yklf)

    xkrf=400+50*sin(radians(-steeringAngle))
    ykrf=450+50*cos(radians(-steeringAngle))
    xkrt=400-50*sin(radians(-steeringAngle))
    ykrt=450-50*cos(radians(-steeringAngle))
    zcanv.coords(frontWheelRight,xkrt,ykrt,xkrf,ykrf)

    xkbl=250+(6*steeringAngle)
    zcanv.coords(blackLine, xkbl,0,xkbl,400)

root.bind('<Motion>', svetofor)

scalAngle=Scale(orient=HORIZONTAL, length=200, from_ =-30, to = 30)
scalAngle.grid(row=0,column=0)


zcanv = Canvas(root, height =600, width=500,bg='green')
frontWheelLeft = zcanv.create_line(100,400,100,500,width=40)
frontWheelRight = zcanv.create_line(400,400,400,500,width=40)

blackLine=zcanv.create_line(250,0,250,400,width=5)

frame1=zcanv.create_line(100,450,400,450,width=5)
frame2=zcanv.create_rectangle(150,380,350,600,width=5)
frame3=zcanv.create_rectangle(85,520,415,600,width=5)
SensLine=ImageTk.PhotoImage(Image.open("E:/Robototechnics/Camaro/Visualisation/SensLine2.png"))
frame4=zcanv.create_image(250,350,image=SensLine)



zcanv.grid(row=1, column=0)


var = 0

def f(event):
    global var
    if var == 0:
        root.attributes("-fullscreen", True)
        var = 1
    else:
        root.attributes("-fullscreen", False)
        var = 0

root.bind("<F11>", f)


def exited():
    root.destroy()
    


exbut = Button(root, command = exited, width= 80,
               height =1, text = 'x', bg ='red',
               foreground ='blue',font=('courier', 20))



exbut.grid(row= 3, column =0,columnspan=3)


root.mainloop()
